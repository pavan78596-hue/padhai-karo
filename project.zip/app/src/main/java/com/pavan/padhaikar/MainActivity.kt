package com.pavan.padhaikar

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var timeTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var accTv: TextView

    private val ticker = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("focus", MODE_PRIVATE)

    private fun label(t: String, size: Float, color: String = "#F2F0E6") = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor(color))
        gravity = Gravity.CENTER
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1F3A32"))
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        infoTv = label("", 16f, "#A9BDB3")
        timeTv = label("--:--", 64f)
        accTv = label("", 15f, "#FF6B5E")
        root.addView(label("Padhai Kar!", 32f))
        root.addView(infoTv)
        root.addView(timeTv)
        for (m in intArrayOf(25, 45, 60)) root.addView(btn("$m min focus") { start(m) })
        root.addView(btn("Focus band karo") {
            prefs().edit().putLong("end", 0L).apply()
            refresh()
        })
        root.addView(accTv)
        root.addView(btn("Blocking ON karo (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        setContentView(root)
    }

    private fun start(m: Int) {
        prefs().edit().putLong("end", System.currentTimeMillis() + m * 60000L).apply()
        refresh()
    }

    private fun refresh() {
        val left = prefs().getLong("end", 0L) - System.currentTimeMillis()
        if (left > 0) {
            val s = left / 1000
            timeTv.text = String.format("%02d:%02d", s / 60, s % 60)
            infoTv.text = "Focus chalu hai. Social media band!"
        } else {
            timeTv.text = "--:--"
            infoTv.text = "Time chuno aur padhai shuru karo."
        }
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        accTv.text = if (enabled) "Blocking ON ✅" else "Blocking OFF. Neeche button dabao, phir 'Padhai Kar' ko ON karo."
    }

    override fun onResume() { super.onResume(); h.post(ticker) }
    override fun onPause() { super.onPause(); h.removeCallbacks(ticker) }
}
