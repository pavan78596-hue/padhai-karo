package com.pavan.padhaikar

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class BlockService : AccessibilityService() {
    private val blocked = setOf(
        "com.instagram.android", "com.instagram.barcelona", "com.google.android.youtube",
        "com.facebook.katana", "com.facebook.lite", "com.snapchat.android",
        "com.twitter.android", "com.whatsapp", "org.telegram.messenger",
        "in.mohalla.sharechat", "in.mohalla.video", "com.reddit.frontpage",
        "com.pinterest", "com.zhiliaoapp.musically"
    )
    private var last = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in blocked) return
        val now = System.currentTimeMillis()
        val end = getSharedPreferences("focus", MODE_PRIVATE).getLong("end", 0L)
        if (now >= end || now - last < 1500) return
        last = now
        startActivity(
            Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    override fun onInterrupt() {}
}
