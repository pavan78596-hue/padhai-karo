package com.pavan.padhaikar

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (28 * resources.displayMetrics.density).toInt()
        val lines = arrayOf(
            "Kahan ja raha hai?! Padhai chhod ke phone chalana hai?",
            "Phir se?! Abhi to shuru kiya tha. Exam mein bhi aise hi bhagega kya?",
            "Mummy-papa mehnat karte hain, aur tu reels dekhega?",
            "Sharam nahi aati? Doosre padh rahe hain, tu skill pe dhyan de.",
            "Ab bas! Kitni baar bolun? Phone side mein rakh aur kaam pe laag."
        )
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#1A0A0A"))
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Ruk ja!"
            textSize = 40f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#FF6B5E"))
        })
        root.addView(TextView(this).apply {
            text = lines.random()
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, pad, 0, pad)
        })
        root.addView(Button(this).apply {
            text = "Sorry, padhai pe wapas"
            isAllCaps = false
            setOnClickListener {
                startActivity(Intent(this@BlockActivity, MainActivity::class.java))
                finish()
            }
        })
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
